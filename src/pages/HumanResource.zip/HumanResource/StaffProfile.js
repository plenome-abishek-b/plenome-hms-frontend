import React from 'react'
import { Container, Col, Row, Card, CardBody } from 'reactstrap'

function StaffProfile() {
  return (
    <React.Fragment>
        <Container fluid>
            <Card>
                <CardBody>
                    <Row>
                        <Col lg='4'>
                            <Card>
                                <CardBody>
                                    
                                </CardBody>
                            </Card>
                        </Col>
                    </Row>
                </CardBody>
            </Card>
        </Container>
    </React.Fragment>
  )
}

export default StaffProfile